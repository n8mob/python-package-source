import setuptools

setuptools.setup(
    name='helloer',
    version='2.0',
    packages=setuptools.find_packages(),
)
