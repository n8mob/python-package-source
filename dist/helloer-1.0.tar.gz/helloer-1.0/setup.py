import setuptools

setuptools.setup(
    name='helloer',
    version='1.0',
    packages=setuptools.find_packages(),
)
