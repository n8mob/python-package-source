import setuptools

setuptools.setup(
    name='helloer',
    packages=['helloer'],
)
